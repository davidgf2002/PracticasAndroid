package com.example.practicadavid_gomez;

import android.app.Activity;
import android.os.Bundle;

public class Segunda_Actividad extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.segunda_actividad);
    }
}
